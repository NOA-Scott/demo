package com.noalabs.tcp;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by Scott on 2016/7/6.
 */
public class TcpClient {

    private static TcpClient instance = null;
    private Socket socket;
    private OutputStream os;
    private InputStream in;
    private String IP = null;
    private int PORT = 5588;
    public Handler mHandler = null;

    public boolean sendMessage = true;
    public boolean autoMessage = true;

    ExecutorService cachedThreadPool = Executors.newCachedThreadPool();

    private long sendTime=0;

    public static TcpClient getInstance() {
        if (instance == null) {
            instance = new TcpClient();
        }
        return instance;
    }

    public void setValue(String ip, Handler handler) {
        this.IP = ip;
        this.mHandler = handler;
    }

    public void sendMessage(final byte[] b) {
        cachedThreadPool.execute(new Runnable() {
            @Override
            public void run() {
                sendTime=System.currentTimeMillis();
                if (os != null) {
                    try {
                        os.write(b);
                        os.flush();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    Runnable connRunnable = new Runnable() {
        @Override
        public void run() {
            cachedThreadPool.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        socket = new Socket(IP, PORT);
                        socket.setSoTimeout(60 * 1000);
                        if (socket.isConnected()) {//连接成功
                            os = socket.getOutputStream();
                            in = socket.getInputStream();
                            Message message = mHandler.obtainMessage();
                            message.what = 101;
                            mHandler.sendMessage(message);

                            mHandler.post(receiveRunnable);
                        } else {//连接失败
                            Message message = mHandler.obtainMessage();
                            message.what = 102;
                            mHandler.sendMessage(message);
                        }
                    } catch (Exception e) {//连接失败
                        Message message = mHandler.obtainMessage();
                        message.what = 102;
                        mHandler.sendMessage(message);
                        e.printStackTrace();
                    }
                }
            });
        }
    };


    Runnable receiveRunnable = new Runnable() {
        @Override
        public void run() {
            cachedThreadPool.execute(new Runnable() {
                @Override
                public void run() {
                    while (sendMessage) {
                        try {
                            byte[] data = new byte[1024];
                            in.read(data);
                            String str = new String(data).trim();
                            Log.e("TAG", str);
                            Message message = mHandler.obtainMessage();
                            message.what = 103;
                            message.obj = str;
                            mHandler.sendMessage(message);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
        }
    };

    public void conn() {
        mHandler.postDelayed(connRunnable, 3000);
    }

    byte[] heartMsg = "Hello NOA-Labs".getBytes();

    Runnable sendMsgRunnable = new Runnable() {
        @Override
        public void run() {
            if (autoMessage&&System.currentTimeMillis()-sendTime>2000) {
                sendMessage(heartMsg);
            }
            mHandler.postDelayed(this, 2000);
        }
    };

    public void sendHeart() {
        mHandler.postDelayed(sendMsgRunnable, 2000);
    }


    public void setAutoMessage(boolean isChecked) {
        this.autoMessage = isChecked;
    }
}
